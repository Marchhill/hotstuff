open Lwt.Syntax
open Capnp_rpc_lwt

let rec print_results sum sqSum count = function
	| (reply, elapsed)::xs -> Fmt.pr "Got reply %S in %fµs@." reply elapsed;
		print_results (sum +. elapsed) (sqSum +. (elapsed *. elapsed)) (count + 1) xs
	| [] -> let mean = (sum /. (float_of_int count)) in
		let sd = sqrt((sqSum /. (float_of_int count)) -. (mean *. mean)) in
		Fmt.pr "Mean response time: %fµs\nStandard deviation: %fµs@." mean sd;
		Lwt.return ()

let print_results = print_results 0. 0. 0

let () =
	Logs.set_level (Some Logs.Warning);
	Logs.set_reporter (Logs_fmt.reporter ())

let secret_key = `Ephemeral
let listen_address = `TCP ("127.0.0.1", 9000)
	
let start_server () =
	let config = Capnp_rpc_unix.Vat_config.create ~secret_key listen_address in
	let service_id = Capnp_rpc_unix.Vat_config.derived_id config "main" in
	let restore = Capnp_rpc_net.Restorer.single service_id Echo.local in
	let+ vat = Capnp_rpc_unix.serve config ~restore in
	Capnp_rpc_unix.Vat.sturdy_uri vat service_id

let run_client msg sr = Capability.with_ref sr (Echo.ping msg)

let () =
	Lwt_main.run begin
		let* uri = start_server () in
		let sr = Capnp_rpc_unix.Vat.import_exn (Capnp_rpc_unix.client_only_vat ()) uri in
		let* results = Lwt_list.map_p
			(fun msg -> Sturdy_ref.with_cap_exn sr (run_client msg))
			(List.init 100 (fun x -> "ping #" ^ (string_of_int x)))
		in
		print_results results
	end